Marlon Bikes PRO

Esta versão inclui:
- Login com email e senha (Firebase Authentication)
- Segurança preparada para Firestore com usuários autenticados
- Backup JSON
- Exportação CSV
- Impressão de ficha
- Orçamento: peças, mão de obra e total
- Status com cores

PASSO 1 — Ativar Authentication
No Firebase:
1. Build -> Authentication
2. Get started
3. Sign-in method
4. Ative "Email/Password"

PASSO 2 — Regras do Firestore
Use estas regras para permitir apenas usuários logados:

rules_version = '2';
service cloud.firestore {
  match /databases/{database}/documents {
    match /clientes_marlon_bikes/{document=**} {
      allow read, write: if request.auth != null;
    }
  }
}

PASSO 3 — Publicar
Troque o index.html do seu repositório por este index.html e aguarde o GitHub Pages atualizar.

PASSO 4 — Primeiro acesso
Abra o site, informe seu email e senha e toque em "Criar conta".
Depois use "Entrar".


Versão corrigida: removido conflito de <script> interno na impressão.